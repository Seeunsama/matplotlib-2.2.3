.. _misc-examples-index:

Miscellaneous
=============
