============================
Plot directive documentation
============================

.. automodule:: matplotlib.sphinxext.plot_directive
   :no-undoc-members:
