.. _MEP-index:

.. include:: README.rst

.. htmlonly::

   :Release: |version|
   :Date: |today|

.. toctree::
   :maxdepth: 1

   template

.. toctree::
   :glob:
   :maxdepth: 1

   MEP*
