***********
collections
***********

.. inheritance-diagram:: matplotlib.collections
   :parts: 2
   :private-bases:

:mod:`matplotlib.collections`
=============================

.. automodule:: matplotlib.collections
   :members:
   :undoc-members:
   :show-inheritance:
   :inherited-members:
